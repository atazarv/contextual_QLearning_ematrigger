"""
EMAModule
~~~~~~

The EMAModule package - a Python package template project that is intended
to be used as a cookie-cutter for developing new Python packages.
"""

from .EMATriggerModule import TriggerModule

